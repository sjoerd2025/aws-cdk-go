import { Resource } from 'aws-cdk-lib';
import type { IRole } from 'aws-cdk-lib/aws-iam';
import { PolicyDocument } from 'aws-cdk-lib/aws-iam';
import type { ISecret } from 'aws-cdk-lib/aws-secretsmanager';
import type { Construct } from 'constructs';
import type { IOriginEndpoint } from './endpoint';
/**
 * Options for configuring CDN Authorization Configuration.
 *
 * @see https://docs.aws.amazon.com/mediapackage/latest/userguide/cdn-auth.html
 */
export interface CdnAuthConfiguration {
    /**
     * Secrets to use for CDN authorization.
     *
     * Each secret must be a JSON object with a `MediaPackageV2CDNIdentifier` key whose
     * value is the CDN-Identifier header value. See the
     * {@link https://docs.aws.amazon.com/mediapackage/latest/userguide/cdn-auth-setup.html | MediaPackage CDN authorization docs}.
     */
    readonly secrets: ISecret[];
    /**
     * Role to use for reading the secrets.
     * If not provided, a role will be created automatically with the required permissions
     * (secretsmanager:GetSecretValue, secretsmanager:DescribeSecret, secretsmanager:BatchGetSecretValue,
     * and kms:Decrypt if the secret uses a customer-managed KMS key).
     *
     * @default - a new role is created
     */
    readonly role?: IRole;
}
/**
 * Properties for Origin Endpoint policy
 */
export interface OriginEndpointPolicyProps {
    /**
     * `OriginEndpoint` to apply the Origin Endpoint Policy to.
     */
    readonly originEndpoint: IOriginEndpoint;
    /**
     * Initial policy document to apply.
     *
     * @default - empty policy document
     */
    readonly policyDocument?: PolicyDocument;
    /**
     * Optional CDN Authorization configuration.
     *
     * @default - No header based CDN authorization
     */
    readonly cdnAuth?: CdnAuthConfiguration;
}
/**
 * The origin endpoint policy for an AWS Elemental MediaPackage V2 Origin Endpoint
 *
 * Policies define the operations that are allowed on this resource.
 *
 * You almost never need to define this construct directly.
 *
 * All AWS resources that support resource policies have a method called
 * `addToResourcePolicy()`, which will automatically create a new resource
 * policy if one doesn't exist yet, otherwise it will add to the existing
 * policy.
 *
 * The origin endpoint policy method is implemented differently than `addToResourcePolicy()`
 * as `OriginEndpointPolicy` creates a new policy without knowing one earlier existed.
 * This will cause a resource conflict if both are invoked (or even multiple origin endpoint
 * policies are defined), so care is to be taken to ensure only 1 policy
 * is created per origin endpoint.
 *
 * Hence it's strongly recommended to use `addToResourcePolicy()`.
 */
export declare class OriginEndpointPolicy extends Resource {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    /**
     * A policy document containing permissions to add to the specified Origin Endpoint.
     */
    readonly document: PolicyDocument;
    constructor(scope: Construct, id: string, props: OriginEndpointPolicyProps);
}
