import type * as cdk from 'aws-cdk-lib/core';
import type { Construct } from 'constructs';
import type { Code } from '../code';
import type { SparkJobProps } from './spark-job';
import { SparkJob } from './spark-job';
/**
 * Properties for a `ScalaSparkFlexEtlJob`.
 */
export interface ScalaSparkFlexEtlJobProps extends SparkJobProps {
    /**
     * Specifies configuration properties of a notification (optional).
     * After a job run starts, the number of minutes to wait before sending a job run delay notification.
     * @default - undefined
     */
    readonly notifyDelayAfter?: cdk.Duration;
    /**
     * The fully qualified Scala class name that serves as the entry point for the job.
     *
     * @see `--class` in https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-glue-arguments.html
     */
    readonly className: string;
    /**
     * Additional files, such as configuration files that AWS Glue copies to the working directory of your script before executing it.
     *
     * @default - no extra files specified.
     *
     * @see https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-glue-arguments.html
     */
    readonly extraFiles?: Code[];
    /**
     * Extra Jars S3 URL (optional)
     * S3 URL where additional jar dependencies are located
     * @default - no extra jar files
     */
    readonly extraJars?: Code[];
    /**
     * Setting this value to true prioritizes the customer's extra JAR files in the classpath.
     *
     * @default false - priority is not given to user-provided jars
     *
     * @see `--user-jars-first` in https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-etl-glue-arguments.html
     */
    readonly extraJarsFirst?: boolean;
}
/**
 * Scala Spark Flex ETL Jobs class
 *
 * Flex jobs support Python and Scala languages.
 * The flexible execution class is appropriate for non-urgent jobs such as
 * pre-production jobs, testing, and one-time data loads.
 * Flexible job runs are supported for jobs using AWS Glue version 3.0 or later and `G_1X` or
 * `G_2X` worker types but will default to the latest version of Glue (currently Glue 5.0).
 *
 * Similar to ETL, we’ll enable these features: --enable-metrics,
 * --enable-continuous-cloudwatch-log. The Spark UI (--enable-spark-ui) is off by
 * default; enable it by setting the `sparkUI` prop.
 */
export declare class ScalaSparkFlexEtlJob extends SparkJob {
    /** Uniquely identifies this class. */
    static readonly PROPERTY_INJECTION_ID: string;
    private resource;
    /**
     * ScalaSparkFlexEtlJob constructor
     */
    constructor(scope: Construct, id: string, props: ScalaSparkFlexEtlJobProps);
    get jobArn(): string;
    get jobName(): string;
    /**
     * Register the executable arguments with best practices enabled by default.
     */
    private executableArguments;
}
