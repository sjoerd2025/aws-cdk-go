const VALIDATORS = { _aws_cdk_aws_glue_alpha_CatalogEncryptionMode: function _aws_cdk_aws_glue_alpha_CatalogEncryptionMode(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.CatalogEncryptionMode", "");
            if (p === "DISABLED")
                print("@aws-cdk/aws-glue-alpha.CatalogEncryptionMode#DISABLED", "");
            if (p === "SSE-KMS")
                print("@aws-cdk/aws-glue-alpha.CatalogEncryptionMode#SSE_KMS", "");
            if (p === "SSE-KMS-WITH-SERVICE-ROLE")
                print("@aws-cdk/aws-glue-alpha.CatalogEncryptionMode#SSE_KMS_WITH_SERVICE_ROLE", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ConnectionPasswordEncryption: function _aws_cdk_aws_glue_alpha_ConnectionPasswordEncryption(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("kmsKey" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionPasswordEncryption#kmsKey", "");
            if ("returnConnectionPasswordEncrypted" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionPasswordEncryption#returnConnectionPasswordEncrypted", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_CatalogEncryptionOptions: function _aws_cdk_aws_glue_alpha_CatalogEncryptionOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("connectionPasswordEncryption" in p)
                print("@aws-cdk/aws-glue-alpha.CatalogEncryptionOptions#connectionPasswordEncryption", "");
            if (!visitedObjects.has(p.connectionPasswordEncryption))
                module.exports._aws_cdk_aws_glue_alpha_ConnectionPasswordEncryption(p.connectionPasswordEncryption);
            if ("encryptionAtRest" in p)
                print("@aws-cdk/aws-glue-alpha.CatalogEncryptionOptions#encryptionAtRest", "");
            if (!visitedObjects.has(p.encryptionAtRest))
                module.exports._aws_cdk_aws_glue_alpha_DataCatalogEncryptionAtRest(p.encryptionAtRest);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_CatalogProps: function _aws_cdk_aws_glue_alpha_CatalogProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("catalogName" in p)
                print("@aws-cdk/aws-glue-alpha.CatalogProps#catalogName", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.CatalogProps#description", "");
            if ("connectionPasswordEncryption" in p)
                print("@aws-cdk/aws-glue-alpha.CatalogEncryptionOptions#connectionPasswordEncryption", "");
            if (!visitedObjects.has(p.connectionPasswordEncryption))
                module.exports._aws_cdk_aws_glue_alpha_ConnectionPasswordEncryption(p.connectionPasswordEncryption);
            if ("encryptionAtRest" in p)
                print("@aws-cdk/aws-glue-alpha.CatalogEncryptionOptions#encryptionAtRest", "");
            if (!visitedObjects.has(p.encryptionAtRest))
                module.exports._aws_cdk_aws_glue_alpha_DataCatalogEncryptionAtRest(p.encryptionAtRest);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_CodeConfig: function _aws_cdk_aws_glue_alpha_CodeConfig(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("s3Location" in p)
                print("@aws-cdk/aws-glue-alpha.CodeConfig#s3Location", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ConnectionOptions: function _aws_cdk_aws_glue_alpha_ConnectionOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("connectionName" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#connectionName", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#description", "");
            if ("matchCriteria" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#matchCriteria", "");
            if ("network" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#network", "");
            if (!visitedObjects.has(p.network))
                module.exports._aws_cdk_aws_glue_alpha_ConnectionNetwork(p.network);
            if ("properties" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#properties", "");
            if ("secret" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#secret", "");
            if ("securityGroups" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#securityGroups", "");
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ConnectionProps: function _aws_cdk_aws_glue_alpha_ConnectionProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("type" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionProps#type", "");
            if (!visitedObjects.has(p.type))
                module.exports._aws_cdk_aws_glue_alpha_ConnectionType(p.type);
            if ("connectionName" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#connectionName", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#description", "");
            if ("matchCriteria" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#matchCriteria", "");
            if ("network" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#network", "");
            if (!visitedObjects.has(p.network))
                module.exports._aws_cdk_aws_glue_alpha_ConnectionNetwork(p.network);
            if ("properties" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#properties", "");
            if ("secret" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#secret", "");
            if ("securityGroups" in p)
                print("@aws-cdk/aws-glue-alpha.ConnectionOptions#securityGroups", "");
            if (p.securityGroups != null)
                for (const o of p.securityGroups)
                    if (!visitedObjects.has(o))
                        require("aws-cdk-lib/.warnings.jsii.js").aws_cdk_lib_aws_ec2_ISecurityGroup(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_DataFormatProps: function _aws_cdk_aws_glue_alpha_DataFormatProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("inputFormat" in p)
                print("@aws-cdk/aws-glue-alpha.DataFormatProps#inputFormat", "");
            if (!visitedObjects.has(p.inputFormat))
                module.exports._aws_cdk_aws_glue_alpha_InputFormat(p.inputFormat);
            if ("outputFormat" in p)
                print("@aws-cdk/aws-glue-alpha.DataFormatProps#outputFormat", "");
            if (!visitedObjects.has(p.outputFormat))
                module.exports._aws_cdk_aws_glue_alpha_OutputFormat(p.outputFormat);
            if ("serializationLibrary" in p)
                print("@aws-cdk/aws-glue-alpha.DataFormatProps#serializationLibrary", "");
            if (!visitedObjects.has(p.serializationLibrary))
                module.exports._aws_cdk_aws_glue_alpha_SerializationLibrary(p.serializationLibrary);
            if ("classificationString" in p)
                print("@aws-cdk/aws-glue-alpha.DataFormatProps#classificationString", "");
            if (!visitedObjects.has(p.classificationString))
                module.exports._aws_cdk_aws_glue_alpha_ClassificationString(p.classificationString);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_DataQualityRulesetProps: function _aws_cdk_aws_glue_alpha_DataQualityRulesetProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("dqdl" in p)
                print("@aws-cdk/aws-glue-alpha.DataQualityRulesetProps#dqdl", "");
            if (!visitedObjects.has(p.dqdl))
                module.exports._aws_cdk_aws_glue_alpha_Dqdl(p.dqdl);
            if ("rulesetName" in p)
                print("@aws-cdk/aws-glue-alpha.DataQualityRulesetProps#rulesetName", "");
            if ("targetTable" in p)
                print("@aws-cdk/aws-glue-alpha.DataQualityRulesetProps#targetTable", "");
            if (!visitedObjects.has(p.targetTable))
                module.exports._aws_cdk_aws_glue_alpha_DataQualityTargetTable(p.targetTable);
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.DataQualityRulesetProps#description", "");
            if ("removalPolicy" in p)
                print("@aws-cdk/aws-glue-alpha.DataQualityRulesetProps#removalPolicy", "");
            if ("tags" in p)
                print("@aws-cdk/aws-glue-alpha.DataQualityRulesetProps#tags", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_DatabaseProps: function _aws_cdk_aws_glue_alpha_DatabaseProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("catalog" in p)
                print("@aws-cdk/aws-glue-alpha.DatabaseProps#catalog", "");
            if (!visitedObjects.has(p.catalog))
                module.exports._aws_cdk_aws_glue_alpha_ICatalog(p.catalog);
            if ("databaseName" in p)
                print("@aws-cdk/aws-glue-alpha.DatabaseProps#databaseName", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.DatabaseProps#description", "");
            if ("locationUri" in p)
                print("@aws-cdk/aws-glue-alpha.DatabaseProps#locationUri", "");
            if ("removalPolicy" in p)
                print("@aws-cdk/aws-glue-alpha.DatabaseProps#removalPolicy", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ExternalTableProps: function _aws_cdk_aws_glue_alpha_ExternalTableProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("connection" in p)
                print("@aws-cdk/aws-glue-alpha.ExternalTableProps#connection", "");
            if (!visitedObjects.has(p.connection))
                module.exports._aws_cdk_aws_glue_alpha_IConnection(p.connection);
            if ("externalDataLocation" in p)
                print("@aws-cdk/aws-glue-alpha.ExternalTableProps#externalDataLocation", "");
            if ("columns" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#columns", "");
            if (p.columns != null)
                for (const o of p.columns)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Column(o);
            if ("database" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#database", "");
            if (!visitedObjects.has(p.database))
                module.exports._aws_cdk_aws_glue_alpha_IDatabase(p.database);
            if ("dataFormat" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#dataFormat", "");
            if (!visitedObjects.has(p.dataFormat))
                module.exports._aws_cdk_aws_glue_alpha_DataFormat(p.dataFormat);
            if ("compressed" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#compressed", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#description", "");
            if ("enablePartitionFiltering" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#enablePartitionFiltering", "");
            if ("hasEncryptedData" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#hasEncryptedData", "");
            if ("parameters" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#parameters", "");
            if ("partitionIndexes" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#partitionIndexes", "");
            if (p.partitionIndexes != null)
                for (const o of p.partitionIndexes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_PartitionIndex(o);
            if ("partitionKeys" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#partitionKeys", "");
            if (p.partitionKeys != null)
                for (const o of p.partitionKeys)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Column(o);
            if ("partitionProjection" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#partitionProjection", "");
            if (p.partitionProjection != null)
                for (const o of Object.values(p.partitionProjection))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_PartitionProjectionConfiguration(o);
            if ("storageParameters" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#storageParameters", "");
            if (p.storageParameters != null)
                for (const o of p.storageParameters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_StorageParameter(o);
            if ("storedAsSubDirectories" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#storedAsSubDirectories", "");
            if ("tableName" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#tableName", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PartitionProjectionType: function _aws_cdk_aws_glue_alpha_PartitionProjectionType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.PartitionProjectionType", "");
            if (p === "integer")
                print("@aws-cdk/aws-glue-alpha.PartitionProjectionType#INTEGER", "");
            if (p === "date")
                print("@aws-cdk/aws-glue-alpha.PartitionProjectionType#DATE", "");
            if (p === "enum")
                print("@aws-cdk/aws-glue-alpha.PartitionProjectionType#ENUM", "");
            if (p === "injected")
                print("@aws-cdk/aws-glue-alpha.PartitionProjectionType#INJECTED", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_DateIntervalUnit: function _aws_cdk_aws_glue_alpha_DateIntervalUnit(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.DateIntervalUnit", "");
            if (p === "YEARS")
                print("@aws-cdk/aws-glue-alpha.DateIntervalUnit#YEARS", "");
            if (p === "MONTHS")
                print("@aws-cdk/aws-glue-alpha.DateIntervalUnit#MONTHS", "");
            if (p === "WEEKS")
                print("@aws-cdk/aws-glue-alpha.DateIntervalUnit#WEEKS", "");
            if (p === "DAYS")
                print("@aws-cdk/aws-glue-alpha.DateIntervalUnit#DAYS", "");
            if (p === "HOURS")
                print("@aws-cdk/aws-glue-alpha.DateIntervalUnit#HOURS", "");
            if (p === "MINUTES")
                print("@aws-cdk/aws-glue-alpha.DateIntervalUnit#MINUTES", "");
            if (p === "SECONDS")
                print("@aws-cdk/aws-glue-alpha.DateIntervalUnit#SECONDS", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_IntegerPartitionProjectionConfigurationProps: function _aws_cdk_aws_glue_alpha_IntegerPartitionProjectionConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("max" in p)
                print("@aws-cdk/aws-glue-alpha.IntegerPartitionProjectionConfigurationProps#max", "");
            if ("min" in p)
                print("@aws-cdk/aws-glue-alpha.IntegerPartitionProjectionConfigurationProps#min", "");
            if ("digits" in p)
                print("@aws-cdk/aws-glue-alpha.IntegerPartitionProjectionConfigurationProps#digits", "");
            if ("interval" in p)
                print("@aws-cdk/aws-glue-alpha.IntegerPartitionProjectionConfigurationProps#interval", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_DateProjectionStep: function _aws_cdk_aws_glue_alpha_DateProjectionStep(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("interval" in p)
                print("@aws-cdk/aws-glue-alpha.DateProjectionStep#interval", "");
            if ("intervalUnit" in p)
                print("@aws-cdk/aws-glue-alpha.DateProjectionStep#intervalUnit", "");
            if (!visitedObjects.has(p.intervalUnit))
                module.exports._aws_cdk_aws_glue_alpha_DateIntervalUnit(p.intervalUnit);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_DatePartitionProjectionConfigurationProps: function _aws_cdk_aws_glue_alpha_DatePartitionProjectionConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("format" in p)
                print("@aws-cdk/aws-glue-alpha.DatePartitionProjectionConfigurationProps#format", "");
            if ("max" in p)
                print("@aws-cdk/aws-glue-alpha.DatePartitionProjectionConfigurationProps#max", "");
            if ("min" in p)
                print("@aws-cdk/aws-glue-alpha.DatePartitionProjectionConfigurationProps#min", "");
            if ("step" in p)
                print("@aws-cdk/aws-glue-alpha.DatePartitionProjectionConfigurationProps#step", "");
            if (!visitedObjects.has(p.step))
                module.exports._aws_cdk_aws_glue_alpha_DateProjectionStep(p.step);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_EnumPartitionProjectionConfigurationProps: function _aws_cdk_aws_glue_alpha_EnumPartitionProjectionConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("values" in p)
                print("@aws-cdk/aws-glue-alpha.EnumPartitionProjectionConfigurationProps#values", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_S3TableProps: function _aws_cdk_aws_glue_alpha_S3TableProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("clientSideEncryption" in p)
                print("@aws-cdk/aws-glue-alpha.S3TableProps#clientSideEncryption", "");
            if (!visitedObjects.has(p.clientSideEncryption))
                module.exports._aws_cdk_aws_glue_alpha_TableClientSideEncryption(p.clientSideEncryption);
            if ("s3Prefix" in p)
                print("@aws-cdk/aws-glue-alpha.S3TableProps#s3Prefix", "");
            if ("storage" in p)
                print("@aws-cdk/aws-glue-alpha.S3TableProps#storage", "");
            if (!visitedObjects.has(p.storage))
                module.exports._aws_cdk_aws_glue_alpha_S3TableStorage(p.storage);
            if ("columns" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#columns", "");
            if (p.columns != null)
                for (const o of p.columns)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Column(o);
            if ("database" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#database", "");
            if (!visitedObjects.has(p.database))
                module.exports._aws_cdk_aws_glue_alpha_IDatabase(p.database);
            if ("dataFormat" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#dataFormat", "");
            if (!visitedObjects.has(p.dataFormat))
                module.exports._aws_cdk_aws_glue_alpha_DataFormat(p.dataFormat);
            if ("compressed" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#compressed", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#description", "");
            if ("enablePartitionFiltering" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#enablePartitionFiltering", "");
            if ("hasEncryptedData" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#hasEncryptedData", "");
            if ("parameters" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#parameters", "");
            if ("partitionIndexes" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#partitionIndexes", "");
            if (p.partitionIndexes != null)
                for (const o of p.partitionIndexes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_PartitionIndex(o);
            if ("partitionKeys" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#partitionKeys", "");
            if (p.partitionKeys != null)
                for (const o of p.partitionKeys)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Column(o);
            if ("partitionProjection" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#partitionProjection", "");
            if (p.partitionProjection != null)
                for (const o of Object.values(p.partitionProjection))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_PartitionProjectionConfiguration(o);
            if ("storageParameters" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#storageParameters", "");
            if (p.storageParameters != null)
                for (const o of p.storageParameters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_StorageParameter(o);
            if ("storedAsSubDirectories" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#storedAsSubDirectories", "");
            if ("tableName" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#tableName", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_Column: function _aws_cdk_aws_glue_alpha_Column(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("name" in p)
                print("@aws-cdk/aws-glue-alpha.Column#name", "");
            if ("type" in p)
                print("@aws-cdk/aws-glue-alpha.Column#type", "");
            if (!visitedObjects.has(p.type))
                module.exports._aws_cdk_aws_glue_alpha_Type(p.type);
            if ("comment" in p)
                print("@aws-cdk/aws-glue-alpha.Column#comment", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_S3EncryptionMode: function _aws_cdk_aws_glue_alpha_S3EncryptionMode(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.S3EncryptionMode", "");
            if (p === "SSE-S3")
                print("@aws-cdk/aws-glue-alpha.S3EncryptionMode#S3_MANAGED", "");
            if (p === "SSE-KMS")
                print("@aws-cdk/aws-glue-alpha.S3EncryptionMode#KMS", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_SecurityConfigurationProps: function _aws_cdk_aws_glue_alpha_SecurityConfigurationProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("cloudWatchEncryption" in p)
                print("@aws-cdk/aws-glue-alpha.SecurityConfigurationProps#cloudWatchEncryption", "");
            if (!visitedObjects.has(p.cloudWatchEncryption))
                module.exports._aws_cdk_aws_glue_alpha_CloudWatchEncryption(p.cloudWatchEncryption);
            if ("jobBookmarksEncryption" in p)
                print("@aws-cdk/aws-glue-alpha.SecurityConfigurationProps#jobBookmarksEncryption", "");
            if (!visitedObjects.has(p.jobBookmarksEncryption))
                module.exports._aws_cdk_aws_glue_alpha_JobBookmarksEncryption(p.jobBookmarksEncryption);
            if ("removalPolicy" in p)
                print("@aws-cdk/aws-glue-alpha.SecurityConfigurationProps#removalPolicy", "");
            if ("s3Encryption" in p)
                print("@aws-cdk/aws-glue-alpha.SecurityConfigurationProps#s3Encryption", "");
            if (!visitedObjects.has(p.s3Encryption))
                module.exports._aws_cdk_aws_glue_alpha_S3Encryption(p.s3Encryption);
            if ("securityConfigurationName" in p)
                print("@aws-cdk/aws-glue-alpha.SecurityConfigurationProps#securityConfigurationName", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_CompressionType: function _aws_cdk_aws_glue_alpha_CompressionType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.CompressionType", "");
            if (p === "none")
                print("@aws-cdk/aws-glue-alpha.CompressionType#NONE", "");
            if (p === "bzip2")
                print("@aws-cdk/aws-glue-alpha.CompressionType#BZIP2", "");
            if (p === "gzip")
                print("@aws-cdk/aws-glue-alpha.CompressionType#GZIP", "");
            if (p === "snappy")
                print("@aws-cdk/aws-glue-alpha.CompressionType#SNAPPY", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_InvalidCharHandlingAction: function _aws_cdk_aws_glue_alpha_InvalidCharHandlingAction(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.InvalidCharHandlingAction", "");
            if (p === "DISABLED")
                print("@aws-cdk/aws-glue-alpha.InvalidCharHandlingAction#DISABLED", "");
            if (p === "FAIL")
                print("@aws-cdk/aws-glue-alpha.InvalidCharHandlingAction#FAIL", "");
            if (p === "SET_TO_NULL")
                print("@aws-cdk/aws-glue-alpha.InvalidCharHandlingAction#SET_TO_NULL", "");
            if (p === "DROP_ROW")
                print("@aws-cdk/aws-glue-alpha.InvalidCharHandlingAction#DROP_ROW", "");
            if (p === "REPLACE")
                print("@aws-cdk/aws-glue-alpha.InvalidCharHandlingAction#REPLACE", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_NumericOverflowHandlingAction: function _aws_cdk_aws_glue_alpha_NumericOverflowHandlingAction(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.NumericOverflowHandlingAction", "");
            if (p === "DISABLED")
                print("@aws-cdk/aws-glue-alpha.NumericOverflowHandlingAction#DISABLED", "");
            if (p === "FAIL")
                print("@aws-cdk/aws-glue-alpha.NumericOverflowHandlingAction#FAIL", "");
            if (p === "SET_TO_NULL")
                print("@aws-cdk/aws-glue-alpha.NumericOverflowHandlingAction#SET_TO_NULL", "");
            if (p === "DROP_ROW")
                print("@aws-cdk/aws-glue-alpha.NumericOverflowHandlingAction#DROP_ROW", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_SurplusBytesHandlingAction: function _aws_cdk_aws_glue_alpha_SurplusBytesHandlingAction(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.SurplusBytesHandlingAction", "");
            if (p === "SET_TO_NULL")
                print("@aws-cdk/aws-glue-alpha.SurplusBytesHandlingAction#SET_TO_NULL", "");
            if (p === "DISABLED")
                print("@aws-cdk/aws-glue-alpha.SurplusBytesHandlingAction#DISABLED", "");
            if (p === "FAIL")
                print("@aws-cdk/aws-glue-alpha.SurplusBytesHandlingAction#FAIL", "");
            if (p === "DROP_ROW")
                print("@aws-cdk/aws-glue-alpha.SurplusBytesHandlingAction#DROP_ROW", "");
            if (p === "TRUNCATE")
                print("@aws-cdk/aws-glue-alpha.SurplusBytesHandlingAction#TRUNCATE", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_SurplusCharHandlingAction: function _aws_cdk_aws_glue_alpha_SurplusCharHandlingAction(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.SurplusCharHandlingAction", "");
            if (p === "SET_TO_NULL")
                print("@aws-cdk/aws-glue-alpha.SurplusCharHandlingAction#SET_TO_NULL", "");
            if (p === "DISABLED")
                print("@aws-cdk/aws-glue-alpha.SurplusCharHandlingAction#DISABLED", "");
            if (p === "FAIL")
                print("@aws-cdk/aws-glue-alpha.SurplusCharHandlingAction#FAIL", "");
            if (p === "DROP_ROW")
                print("@aws-cdk/aws-glue-alpha.SurplusCharHandlingAction#DROP_ROW", "");
            if (p === "TRUNCATE")
                print("@aws-cdk/aws-glue-alpha.SurplusCharHandlingAction#TRUNCATE", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ColumnCountMismatchHandlingAction: function _aws_cdk_aws_glue_alpha_ColumnCountMismatchHandlingAction(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.ColumnCountMismatchHandlingAction", "");
            if (p === "DISABLED")
                print("@aws-cdk/aws-glue-alpha.ColumnCountMismatchHandlingAction#DISABLED", "");
            if (p === "FAIL")
                print("@aws-cdk/aws-glue-alpha.ColumnCountMismatchHandlingAction#FAIL", "");
            if (p === "SET_TO_NULL")
                print("@aws-cdk/aws-glue-alpha.ColumnCountMismatchHandlingAction#SET_TO_NULL", "");
            if (p === "DROP_ROW")
                print("@aws-cdk/aws-glue-alpha.ColumnCountMismatchHandlingAction#DROP_ROW", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_WriteParallel: function _aws_cdk_aws_glue_alpha_WriteParallel(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.WriteParallel", "");
            if (p === "on")
                print("@aws-cdk/aws-glue-alpha.WriteParallel#ON", "");
            if (p === "off")
                print("@aws-cdk/aws-glue-alpha.WriteParallel#OFF", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_OrcColumnMappingType: function _aws_cdk_aws_glue_alpha_OrcColumnMappingType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.OrcColumnMappingType", "");
            if (p === "name")
                print("@aws-cdk/aws-glue-alpha.OrcColumnMappingType#NAME", "");
            if (p === "position")
                print("@aws-cdk/aws-glue-alpha.OrcColumnMappingType#POSITION", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_StorageParameters: function _aws_cdk_aws_glue_alpha_StorageParameters(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.StorageParameters", "");
            if (p === "skip.header.line.count")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#SKIP_HEADER_LINE_COUNT", "");
            if (p === "data_cleansing_enabled")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#DATA_CLEANSING_ENABLED", "");
            if (p === "compression_type")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#COMPRESSION_TYPE", "");
            if (p === "invalid_char_handling")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#INVALID_CHAR_HANDLING", "");
            if (p === "replacement_char")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#REPLACEMENT_CHAR", "");
            if (p === "numeric_overflow_handling")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#NUMERIC_OVERFLOW_HANDLING", "");
            if (p === "surplus_bytes_handling")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#SURPLUS_BYTES_HANDLING", "");
            if (p === "surplus_char_handling")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#SURPLUS_CHAR_HANDLING", "");
            if (p === "column_count_mismatch_handling")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#COLUMN_COUNT_MISMATCH_HANDLING", "");
            if (p === "num_rows")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#NUM_ROWS", "");
            if (p === "serialization.null.format")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#SERIALIZATION_NULL_FORMAT", "");
            if (p === "orc.schema.resolution")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#ORC_SCHEMA_RESOLUTION", "");
            if (p === "write.parallel")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#WRITE_PARALLEL", "");
            if (p === "write.maxfilesize.mb")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#WRITE_MAX_FILESIZE_MB", "");
            if (p === "write.kms.key.id")
                print("@aws-cdk/aws-glue-alpha.StorageParameters#WRITE_KMS_KEY_ID", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_WorkerType: function _aws_cdk_aws_glue_alpha_WorkerType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.WorkerType", "");
            if (p === "Standard")
                print("@aws-cdk/aws-glue-alpha.WorkerType#STANDARD", "");
            if (p === "G.1X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#G_1X", "");
            if (p === "G.2X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#G_2X", "");
            if (p === "G.4X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#G_4X", "");
            if (p === "G.8X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#G_8X", "");
            if (p === "G.12X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#G_12X", "");
            if (p === "G.16X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#G_16X", "");
            if (p === "G.025X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#G_025X", "");
            if (p === "Z.2X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#Z_2X", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nThis worker type was only used for Ray jobs. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if (p === "R.1X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#R_1X", "");
            if (p === "R.2X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#R_2X", "");
            if (p === "R.4X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#R_4X", "");
            if (p === "R.8X")
                print("@aws-cdk/aws-glue-alpha.WorkerType#R_8X", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_JobState: function _aws_cdk_aws_glue_alpha_JobState(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.JobState", "");
            if (p === "SUCCEEDED")
                print("@aws-cdk/aws-glue-alpha.JobState#SUCCEEDED", "");
            if (p === "FAILED")
                print("@aws-cdk/aws-glue-alpha.JobState#FAILED", "");
            if (p === "TIMEOUT")
                print("@aws-cdk/aws-glue-alpha.JobState#TIMEOUT", "");
            if (p === "STARTING")
                print("@aws-cdk/aws-glue-alpha.JobState#STARTING", "");
            if (p === "RUNNING")
                print("@aws-cdk/aws-glue-alpha.JobState#RUNNING", "");
            if (p === "STOPPING")
                print("@aws-cdk/aws-glue-alpha.JobState#STOPPING", "");
            if (p === "STOPPED")
                print("@aws-cdk/aws-glue-alpha.JobState#STOPPED", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_MetricType: function _aws_cdk_aws_glue_alpha_MetricType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.MetricType", "");
            if (p === "gauge")
                print("@aws-cdk/aws-glue-alpha.MetricType#GAUGE", "");
            if (p === "count")
                print("@aws-cdk/aws-glue-alpha.MetricType#COUNT", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ExecutionClass: function _aws_cdk_aws_glue_alpha_ExecutionClass(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.ExecutionClass", "");
            if (p === "FLEX")
                print("@aws-cdk/aws-glue-alpha.ExecutionClass#FLEX", "");
            if (p === "STANDARD")
                print("@aws-cdk/aws-glue-alpha.ExecutionClass#STANDARD", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_GlueVersion: function _aws_cdk_aws_glue_alpha_GlueVersion(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.GlueVersion", "");
            if (p === "0.9")
                print("@aws-cdk/aws-glue-alpha.GlueVersion#V0_9", "");
            if (p === "1.0")
                print("@aws-cdk/aws-glue-alpha.GlueVersion#V1_0", "");
            if (p === "2.0")
                print("@aws-cdk/aws-glue-alpha.GlueVersion#V2_0", "");
            if (p === "3.0")
                print("@aws-cdk/aws-glue-alpha.GlueVersion#V3_0", "");
            if (p === "4.0")
                print("@aws-cdk/aws-glue-alpha.GlueVersion#V4_0", "");
            if (p === "5.0")
                print("@aws-cdk/aws-glue-alpha.GlueVersion#V5_0", "");
            if (p === "5.1")
                print("@aws-cdk/aws-glue-alpha.GlueVersion#V5_1", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_JobLanguage: function _aws_cdk_aws_glue_alpha_JobLanguage(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.JobLanguage", "");
            if (p === "scala")
                print("@aws-cdk/aws-glue-alpha.JobLanguage#SCALA", "");
            if (p === "python")
                print("@aws-cdk/aws-glue-alpha.JobLanguage#PYTHON", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PythonVersion: function _aws_cdk_aws_glue_alpha_PythonVersion(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.PythonVersion", "");
            if (p === "2")
                print("@aws-cdk/aws-glue-alpha.PythonVersion#TWO", "");
            if (p === "3")
                print("@aws-cdk/aws-glue-alpha.PythonVersion#THREE", "");
            if (p === "3.9")
                print("@aws-cdk/aws-glue-alpha.PythonVersion#THREE_NINE", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_LibrarySet: function _aws_cdk_aws_glue_alpha_LibrarySet(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.LibrarySet", "");
            if (p === "analytics")
                print("@aws-cdk/aws-glue-alpha.LibrarySet#ANALYTICS", "");
            if (p === "none")
                print("@aws-cdk/aws-glue-alpha.LibrarySet#NONE", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_Runtime: function _aws_cdk_aws_glue_alpha_Runtime(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.Runtime", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if (p === "Ray2.4")
                print("@aws-cdk/aws-glue-alpha.Runtime#RAY_TWO_FOUR", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_JobType: function _aws_cdk_aws_glue_alpha_JobType(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.JobType", "");
            if (p === "glueetl")
                print("@aws-cdk/aws-glue-alpha.JobType#ETL", "");
            if (p === "gluestreaming")
                print("@aws-cdk/aws-glue-alpha.JobType#STREAMING", "");
            if (p === "pythonshell")
                print("@aws-cdk/aws-glue-alpha.JobType#PYTHON_SHELL", "");
            if (p === "glueray")
                print("@aws-cdk/aws-glue-alpha.JobType#RAY", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_MaxCapacity: function _aws_cdk_aws_glue_alpha_MaxCapacity(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.MaxCapacity", "");
            if (p === 0.0625)
                print("@aws-cdk/aws-glue-alpha.MaxCapacity#DPU_1_16TH", "");
            if (p === 1)
                print("@aws-cdk/aws-glue-alpha.MaxCapacity#DPU_1", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PredicateLogical: function _aws_cdk_aws_glue_alpha_PredicateLogical(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.PredicateLogical", "");
            if (p === "AND")
                print("@aws-cdk/aws-glue-alpha.PredicateLogical#AND", "");
            if (p === "ANY")
                print("@aws-cdk/aws-glue-alpha.PredicateLogical#ANY", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ConditionLogicalOperator: function _aws_cdk_aws_glue_alpha_ConditionLogicalOperator(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.ConditionLogicalOperator", "");
            if (p === "EQUALS")
                print("@aws-cdk/aws-glue-alpha.ConditionLogicalOperator#EQUALS", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_CrawlerState: function _aws_cdk_aws_glue_alpha_CrawlerState(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            print("@aws-cdk/aws-glue-alpha.CrawlerState", "");
            if (p === "RUNNING")
                print("@aws-cdk/aws-glue-alpha.CrawlerState#RUNNING", "");
            if (p === "CANCELLING")
                print("@aws-cdk/aws-glue-alpha.CrawlerState#CANCELLING", "");
            if (p === "CANCELLED")
                print("@aws-cdk/aws-glue-alpha.CrawlerState#CANCELLED", "");
            if (p === "SUCCEEDED")
                print("@aws-cdk/aws-glue-alpha.CrawlerState#SUCCEEDED", "");
            if (p === "FAILED")
                print("@aws-cdk/aws-glue-alpha.CrawlerState#FAILED", "");
            if (p === "ERROR")
                print("@aws-cdk/aws-glue-alpha.CrawlerState#ERROR", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ContinuousLoggingProps: function _aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("enabled" in p)
                print("@aws-cdk/aws-glue-alpha.ContinuousLoggingProps#enabled", "");
            if ("conversionPattern" in p)
                print("@aws-cdk/aws-glue-alpha.ContinuousLoggingProps#conversionPattern", "");
            if ("logGroup" in p)
                print("@aws-cdk/aws-glue-alpha.ContinuousLoggingProps#logGroup", "");
            if ("logStreamPrefix" in p)
                print("@aws-cdk/aws-glue-alpha.ContinuousLoggingProps#logStreamPrefix", "");
            if ("quiet" in p)
                print("@aws-cdk/aws-glue-alpha.ContinuousLoggingProps#quiet", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_JobAttributes: function _aws_cdk_aws_glue_alpha_JobAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("jobName" in p)
                print("@aws-cdk/aws-glue-alpha.JobAttributes#jobName", "");
            if ("role" in p)
                print("@aws-cdk/aws-glue-alpha.JobAttributes#role", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_JobProps: function _aws_cdk_aws_glue_alpha_JobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("role" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#role", "");
            if ("script" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#script", "");
            if (!visitedObjects.has(p.script))
                module.exports._aws_cdk_aws_glue_alpha_Code(p.script);
            if ("connections" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#connections", "");
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if ("continuousLogging" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#continuousLogging", "");
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
            if ("defaultArguments" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#defaultArguments", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#description", "");
            if ("glueVersion" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#glueVersion", "");
            if (!visitedObjects.has(p.glueVersion))
                module.exports._aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
            if ("jobName" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#jobName", "");
            if ("maxConcurrentRuns" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxConcurrentRuns", "");
            if ("maxRetries" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxRetries", "");
            if ("securityConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#securityConfiguration", "");
            if (!visitedObjects.has(p.securityConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
            if ("tags" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#tags", "");
            if ("timeout" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#timeout", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_SparkExtraCodeProps: function _aws_cdk_aws_glue_alpha_SparkExtraCodeProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("extraFiles" in p)
                print("@aws-cdk/aws-glue-alpha.SparkExtraCodeProps#extraFiles", "");
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJars" in p)
                print("@aws-cdk/aws-glue-alpha.SparkExtraCodeProps#extraJars", "");
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJarsFirst" in p)
                print("@aws-cdk/aws-glue-alpha.SparkExtraCodeProps#extraJarsFirst", "");
            if ("extraPythonFiles" in p)
                print("@aws-cdk/aws-glue-alpha.SparkExtraCodeProps#extraPythonFiles", "");
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_SparkUIProps: function _aws_cdk_aws_glue_alpha_SparkUIProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("bucket" in p)
                print("@aws-cdk/aws-glue-alpha.SparkUIProps#bucket", "");
            if ("prefix" in p)
                print("@aws-cdk/aws-glue-alpha.SparkUIProps#prefix", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_SparkUILoggingLocation: function _aws_cdk_aws_glue_alpha_SparkUILoggingLocation(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("bucket" in p)
                print("@aws-cdk/aws-glue-alpha.SparkUILoggingLocation#bucket", "");
            if ("prefix" in p)
                print("@aws-cdk/aws-glue-alpha.SparkUILoggingLocation#prefix", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_WorkerConfiguration: function _aws_cdk_aws_glue_alpha_WorkerConfiguration(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("numberOfWorkers" in p)
                print("@aws-cdk/aws-glue-alpha.WorkerConfiguration#numberOfWorkers", "");
            if ("workerType" in p)
                print("@aws-cdk/aws-glue-alpha.WorkerConfiguration#workerType", "");
            if (!visitedObjects.has(p.workerType))
                module.exports._aws_cdk_aws_glue_alpha_WorkerType(p.workerType);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_SparkJobProps: function _aws_cdk_aws_glue_alpha_SparkJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("enableMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableMetrics", "");
            if ("enableObservabilityMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableObservabilityMetrics", "");
            if ("sparkUI" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#sparkUI", "");
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if ("workerConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#workerConfiguration", "");
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if ("role" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#role", "");
            if ("script" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#script", "");
            if (!visitedObjects.has(p.script))
                module.exports._aws_cdk_aws_glue_alpha_Code(p.script);
            if ("connections" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#connections", "");
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if ("continuousLogging" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#continuousLogging", "");
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
            if ("defaultArguments" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#defaultArguments", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#description", "");
            if ("glueVersion" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#glueVersion", "");
            if (!visitedObjects.has(p.glueVersion))
                module.exports._aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
            if ("jobName" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#jobName", "");
            if ("maxConcurrentRuns" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxConcurrentRuns", "");
            if ("maxRetries" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxRetries", "");
            if ("securityConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#securityConfiguration", "");
            if (!visitedObjects.has(p.securityConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
            if ("tags" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#tags", "");
            if ("timeout" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#timeout", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PySparkEtlJobProps: function _aws_cdk_aws_glue_alpha_PySparkEtlJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("extraFiles" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkEtlJobProps#extraFiles", "");
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJars" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkEtlJobProps#extraJars", "");
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJarsFirst" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkEtlJobProps#extraJarsFirst", "");
            if ("extraPythonFiles" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkEtlJobProps#extraPythonFiles", "");
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("jobRunQueuingEnabled" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkEtlJobProps#jobRunQueuingEnabled", "");
            if ("notifyDelayAfter" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkEtlJobProps#notifyDelayAfter", "");
            if ("enableMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableMetrics", "");
            if ("enableObservabilityMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableObservabilityMetrics", "");
            if ("sparkUI" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#sparkUI", "");
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if ("workerConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#workerConfiguration", "");
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if ("role" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#role", "");
            if ("script" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#script", "");
            if (!visitedObjects.has(p.script))
                module.exports._aws_cdk_aws_glue_alpha_Code(p.script);
            if ("connections" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#connections", "");
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if ("continuousLogging" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#continuousLogging", "");
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
            if ("defaultArguments" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#defaultArguments", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#description", "");
            if ("glueVersion" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#glueVersion", "");
            if (!visitedObjects.has(p.glueVersion))
                module.exports._aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
            if ("jobName" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#jobName", "");
            if ("maxConcurrentRuns" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxConcurrentRuns", "");
            if ("maxRetries" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxRetries", "");
            if ("securityConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#securityConfiguration", "");
            if (!visitedObjects.has(p.securityConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
            if ("tags" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#tags", "");
            if ("timeout" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#timeout", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PySparkFlexEtlJobProps: function _aws_cdk_aws_glue_alpha_PySparkFlexEtlJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("extraFiles" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkFlexEtlJobProps#extraFiles", "");
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJars" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkFlexEtlJobProps#extraJars", "");
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJarsFirst" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkFlexEtlJobProps#extraJarsFirst", "");
            if ("extraPythonFiles" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkFlexEtlJobProps#extraPythonFiles", "");
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("notifyDelayAfter" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkFlexEtlJobProps#notifyDelayAfter", "");
            if ("enableMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableMetrics", "");
            if ("enableObservabilityMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableObservabilityMetrics", "");
            if ("sparkUI" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#sparkUI", "");
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if ("workerConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#workerConfiguration", "");
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if ("role" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#role", "");
            if ("script" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#script", "");
            if (!visitedObjects.has(p.script))
                module.exports._aws_cdk_aws_glue_alpha_Code(p.script);
            if ("connections" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#connections", "");
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if ("continuousLogging" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#continuousLogging", "");
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
            if ("defaultArguments" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#defaultArguments", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#description", "");
            if ("glueVersion" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#glueVersion", "");
            if (!visitedObjects.has(p.glueVersion))
                module.exports._aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
            if ("jobName" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#jobName", "");
            if ("maxConcurrentRuns" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxConcurrentRuns", "");
            if ("maxRetries" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxRetries", "");
            if ("securityConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#securityConfiguration", "");
            if (!visitedObjects.has(p.securityConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
            if ("tags" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#tags", "");
            if ("timeout" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#timeout", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PySparkStreamingJobProps: function _aws_cdk_aws_glue_alpha_PySparkStreamingJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("extraFiles" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkStreamingJobProps#extraFiles", "");
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJars" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkStreamingJobProps#extraJars", "");
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJarsFirst" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkStreamingJobProps#extraJarsFirst", "");
            if ("extraPythonFiles" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkStreamingJobProps#extraPythonFiles", "");
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("jobRunQueuingEnabled" in p)
                print("@aws-cdk/aws-glue-alpha.PySparkStreamingJobProps#jobRunQueuingEnabled", "");
            if ("enableMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableMetrics", "");
            if ("enableObservabilityMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableObservabilityMetrics", "");
            if ("sparkUI" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#sparkUI", "");
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if ("workerConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#workerConfiguration", "");
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if ("role" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#role", "");
            if ("script" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#script", "");
            if (!visitedObjects.has(p.script))
                module.exports._aws_cdk_aws_glue_alpha_Code(p.script);
            if ("connections" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#connections", "");
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if ("continuousLogging" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#continuousLogging", "");
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
            if ("defaultArguments" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#defaultArguments", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#description", "");
            if ("glueVersion" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#glueVersion", "");
            if (!visitedObjects.has(p.glueVersion))
                module.exports._aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
            if ("jobName" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#jobName", "");
            if ("maxConcurrentRuns" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxConcurrentRuns", "");
            if ("maxRetries" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxRetries", "");
            if ("securityConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#securityConfiguration", "");
            if (!visitedObjects.has(p.securityConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
            if ("tags" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#tags", "");
            if ("timeout" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#timeout", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PythonShellJobProps: function _aws_cdk_aws_glue_alpha_PythonShellJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("extraPythonFiles" in p)
                print("@aws-cdk/aws-glue-alpha.PythonShellJobProps#extraPythonFiles", "");
            if (p.extraPythonFiles != null)
                for (const o of p.extraPythonFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("jobRunQueuingEnabled" in p)
                print("@aws-cdk/aws-glue-alpha.PythonShellJobProps#jobRunQueuingEnabled", "");
            if ("librarySet" in p)
                print("@aws-cdk/aws-glue-alpha.PythonShellJobProps#librarySet", "");
            if (!visitedObjects.has(p.librarySet))
                module.exports._aws_cdk_aws_glue_alpha_LibrarySet(p.librarySet);
            if ("maxCapacity" in p)
                print("@aws-cdk/aws-glue-alpha.PythonShellJobProps#maxCapacity", "");
            if (!visitedObjects.has(p.maxCapacity))
                module.exports._aws_cdk_aws_glue_alpha_MaxCapacity(p.maxCapacity);
            if ("pythonVersion" in p)
                print("@aws-cdk/aws-glue-alpha.PythonShellJobProps#pythonVersion", "");
            if (!visitedObjects.has(p.pythonVersion))
                module.exports._aws_cdk_aws_glue_alpha_PythonVersion(p.pythonVersion);
            if ("role" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#role", "");
            if ("script" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#script", "");
            if (!visitedObjects.has(p.script))
                module.exports._aws_cdk_aws_glue_alpha_Code(p.script);
            if ("connections" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#connections", "");
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if ("continuousLogging" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#continuousLogging", "");
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
            if ("defaultArguments" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#defaultArguments", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#description", "");
            if ("glueVersion" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#glueVersion", "");
            if (!visitedObjects.has(p.glueVersion))
                module.exports._aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
            if ("jobName" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#jobName", "");
            if ("maxConcurrentRuns" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxConcurrentRuns", "");
            if ("maxRetries" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxRetries", "");
            if ("securityConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#securityConfiguration", "");
            if (!visitedObjects.has(p.securityConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
            if ("tags" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#tags", "");
            if ("timeout" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#timeout", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_RayJobProps: function _aws_cdk_aws_glue_alpha_RayJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("enableMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.RayJobProps#enableMetrics", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if ("enableObservabilityMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.RayJobProps#enableObservabilityMetrics", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if ("jobRunQueuingEnabled" in p)
                print("@aws-cdk/aws-glue-alpha.RayJobProps#jobRunQueuingEnabled", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if ("numberOfWorkers" in p)
                print("@aws-cdk/aws-glue-alpha.RayJobProps#numberOfWorkers", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if ("runtime" in p)
                print("@aws-cdk/aws-glue-alpha.RayJobProps#runtime", "AWS Glue for Ray is closed to new customers as of April 30, 2026.\nMigrate to Amazon EKS with KubeRay Operator. See\nhttps://docs.aws.amazon.com/glue/latest/dg/awsglue-ray-jobs-availability-change.html");
            if (!visitedObjects.has(p.runtime))
                module.exports._aws_cdk_aws_glue_alpha_Runtime(p.runtime);
            if ("role" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#role", "");
            if ("script" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#script", "");
            if (!visitedObjects.has(p.script))
                module.exports._aws_cdk_aws_glue_alpha_Code(p.script);
            if ("connections" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#connections", "");
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if ("continuousLogging" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#continuousLogging", "");
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
            if ("defaultArguments" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#defaultArguments", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#description", "");
            if ("glueVersion" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#glueVersion", "");
            if (!visitedObjects.has(p.glueVersion))
                module.exports._aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
            if ("jobName" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#jobName", "");
            if ("maxConcurrentRuns" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxConcurrentRuns", "");
            if ("maxRetries" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxRetries", "");
            if ("securityConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#securityConfiguration", "");
            if (!visitedObjects.has(p.securityConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
            if ("tags" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#tags", "");
            if ("timeout" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#timeout", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ScalaSparkEtlJobProps: function _aws_cdk_aws_glue_alpha_ScalaSparkEtlJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("className" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkEtlJobProps#className", "");
            if ("extraFiles" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkEtlJobProps#extraFiles", "");
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJars" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkEtlJobProps#extraJars", "");
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJarsFirst" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkEtlJobProps#extraJarsFirst", "");
            if ("jobRunQueuingEnabled" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkEtlJobProps#jobRunQueuingEnabled", "");
            if ("notifyDelayAfter" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkEtlJobProps#notifyDelayAfter", "");
            if ("enableMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableMetrics", "");
            if ("enableObservabilityMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableObservabilityMetrics", "");
            if ("sparkUI" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#sparkUI", "");
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if ("workerConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#workerConfiguration", "");
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if ("role" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#role", "");
            if ("script" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#script", "");
            if (!visitedObjects.has(p.script))
                module.exports._aws_cdk_aws_glue_alpha_Code(p.script);
            if ("connections" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#connections", "");
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if ("continuousLogging" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#continuousLogging", "");
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
            if ("defaultArguments" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#defaultArguments", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#description", "");
            if ("glueVersion" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#glueVersion", "");
            if (!visitedObjects.has(p.glueVersion))
                module.exports._aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
            if ("jobName" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#jobName", "");
            if ("maxConcurrentRuns" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxConcurrentRuns", "");
            if ("maxRetries" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxRetries", "");
            if ("securityConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#securityConfiguration", "");
            if (!visitedObjects.has(p.securityConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
            if ("tags" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#tags", "");
            if ("timeout" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#timeout", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ScalaSparkFlexEtlJobProps: function _aws_cdk_aws_glue_alpha_ScalaSparkFlexEtlJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("className" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkFlexEtlJobProps#className", "");
            if ("extraFiles" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkFlexEtlJobProps#extraFiles", "");
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJars" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkFlexEtlJobProps#extraJars", "");
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJarsFirst" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkFlexEtlJobProps#extraJarsFirst", "");
            if ("notifyDelayAfter" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkFlexEtlJobProps#notifyDelayAfter", "");
            if ("enableMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableMetrics", "");
            if ("enableObservabilityMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableObservabilityMetrics", "");
            if ("sparkUI" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#sparkUI", "");
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if ("workerConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#workerConfiguration", "");
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if ("role" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#role", "");
            if ("script" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#script", "");
            if (!visitedObjects.has(p.script))
                module.exports._aws_cdk_aws_glue_alpha_Code(p.script);
            if ("connections" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#connections", "");
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if ("continuousLogging" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#continuousLogging", "");
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
            if ("defaultArguments" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#defaultArguments", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#description", "");
            if ("glueVersion" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#glueVersion", "");
            if (!visitedObjects.has(p.glueVersion))
                module.exports._aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
            if ("jobName" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#jobName", "");
            if ("maxConcurrentRuns" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxConcurrentRuns", "");
            if ("maxRetries" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxRetries", "");
            if ("securityConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#securityConfiguration", "");
            if (!visitedObjects.has(p.securityConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
            if ("tags" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#tags", "");
            if ("timeout" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#timeout", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ScalaSparkStreamingJobProps: function _aws_cdk_aws_glue_alpha_ScalaSparkStreamingJobProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("className" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkStreamingJobProps#className", "");
            if ("extraFiles" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkStreamingJobProps#extraFiles", "");
            if (p.extraFiles != null)
                for (const o of p.extraFiles)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJars" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkStreamingJobProps#extraJars", "");
            if (p.extraJars != null)
                for (const o of p.extraJars)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Code(o);
            if ("extraJarsFirst" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkStreamingJobProps#extraJarsFirst", "");
            if ("jobRunQueuingEnabled" in p)
                print("@aws-cdk/aws-glue-alpha.ScalaSparkStreamingJobProps#jobRunQueuingEnabled", "");
            if ("enableMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableMetrics", "");
            if ("enableObservabilityMetrics" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#enableObservabilityMetrics", "");
            if ("sparkUI" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#sparkUI", "");
            if (!visitedObjects.has(p.sparkUI))
                module.exports._aws_cdk_aws_glue_alpha_SparkUIProps(p.sparkUI);
            if ("workerConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.SparkJobProps#workerConfiguration", "");
            if (!visitedObjects.has(p.workerConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_WorkerConfiguration(p.workerConfiguration);
            if ("role" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#role", "");
            if ("script" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#script", "");
            if (!visitedObjects.has(p.script))
                module.exports._aws_cdk_aws_glue_alpha_Code(p.script);
            if ("connections" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#connections", "");
            if (p.connections != null)
                for (const o of p.connections)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_IConnection(o);
            if ("continuousLogging" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#continuousLogging", "");
            if (!visitedObjects.has(p.continuousLogging))
                module.exports._aws_cdk_aws_glue_alpha_ContinuousLoggingProps(p.continuousLogging);
            if ("defaultArguments" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#defaultArguments", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#description", "");
            if ("glueVersion" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#glueVersion", "");
            if (!visitedObjects.has(p.glueVersion))
                module.exports._aws_cdk_aws_glue_alpha_GlueVersion(p.glueVersion);
            if ("jobName" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#jobName", "");
            if ("maxConcurrentRuns" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxConcurrentRuns", "");
            if ("maxRetries" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#maxRetries", "");
            if ("securityConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#securityConfiguration", "");
            if (!visitedObjects.has(p.securityConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
            if ("tags" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#tags", "");
            if ("timeout" in p)
                print("@aws-cdk/aws-glue-alpha.JobProps#timeout", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_PartitionIndex: function _aws_cdk_aws_glue_alpha_PartitionIndex(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("keyNames" in p)
                print("@aws-cdk/aws-glue-alpha.PartitionIndex#keyNames", "");
            if ("indexName" in p)
                print("@aws-cdk/aws-glue-alpha.PartitionIndex#indexName", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_TableAttributes: function _aws_cdk_aws_glue_alpha_TableAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("tableArn" in p)
                print("@aws-cdk/aws-glue-alpha.TableAttributes#tableArn", "");
            if ("tableName" in p)
                print("@aws-cdk/aws-glue-alpha.TableAttributes#tableName", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_TableBaseProps: function _aws_cdk_aws_glue_alpha_TableBaseProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("columns" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#columns", "");
            if (p.columns != null)
                for (const o of p.columns)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Column(o);
            if ("database" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#database", "");
            if (!visitedObjects.has(p.database))
                module.exports._aws_cdk_aws_glue_alpha_IDatabase(p.database);
            if ("dataFormat" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#dataFormat", "");
            if (!visitedObjects.has(p.dataFormat))
                module.exports._aws_cdk_aws_glue_alpha_DataFormat(p.dataFormat);
            if ("compressed" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#compressed", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#description", "");
            if ("enablePartitionFiltering" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#enablePartitionFiltering", "");
            if ("hasEncryptedData" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#hasEncryptedData", "");
            if ("parameters" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#parameters", "");
            if ("partitionIndexes" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#partitionIndexes", "");
            if (p.partitionIndexes != null)
                for (const o of p.partitionIndexes)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_PartitionIndex(o);
            if ("partitionKeys" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#partitionKeys", "");
            if (p.partitionKeys != null)
                for (const o of p.partitionKeys)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Column(o);
            if ("partitionProjection" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#partitionProjection", "");
            if (p.partitionProjection != null)
                for (const o of Object.values(p.partitionProjection))
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_PartitionProjectionConfiguration(o);
            if ("storageParameters" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#storageParameters", "");
            if (p.storageParameters != null)
                for (const o of p.storageParameters)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_StorageParameter(o);
            if ("storedAsSubDirectories" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#storedAsSubDirectories", "");
            if ("tableName" in p)
                print("@aws-cdk/aws-glue-alpha.TableBaseProps#tableName", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_WorkflowAttributes: function _aws_cdk_aws_glue_alpha_WorkflowAttributes(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("workflowName" in p)
                print("@aws-cdk/aws-glue-alpha.WorkflowAttributes#workflowName", "");
            if ("workflowArn" in p)
                print("@aws-cdk/aws-glue-alpha.WorkflowAttributes#workflowArn", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_WorkflowProps: function _aws_cdk_aws_glue_alpha_WorkflowProps(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("defaultRunProperties" in p)
                print("@aws-cdk/aws-glue-alpha.WorkflowProps#defaultRunProperties", "");
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.WorkflowProps#description", "");
            if ("maxConcurrentRuns" in p)
                print("@aws-cdk/aws-glue-alpha.WorkflowProps#maxConcurrentRuns", "");
            if ("workflowName" in p)
                print("@aws-cdk/aws-glue-alpha.WorkflowProps#workflowName", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_CrawlerActionOptions: function _aws_cdk_aws_glue_alpha_CrawlerActionOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("arguments" in p)
                print("@aws-cdk/aws-glue-alpha.CrawlerActionOptions#arguments", "");
            if ("securityConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.CrawlerActionOptions#securityConfiguration", "");
            if (!visitedObjects.has(p.securityConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
            if ("timeout" in p)
                print("@aws-cdk/aws-glue-alpha.CrawlerActionOptions#timeout", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_JobActionOptions: function _aws_cdk_aws_glue_alpha_JobActionOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("arguments" in p)
                print("@aws-cdk/aws-glue-alpha.JobActionOptions#arguments", "");
            if ("securityConfiguration" in p)
                print("@aws-cdk/aws-glue-alpha.JobActionOptions#securityConfiguration", "");
            if (!visitedObjects.has(p.securityConfiguration))
                module.exports._aws_cdk_aws_glue_alpha_ISecurityConfiguration(p.securityConfiguration);
            if ("timeout" in p)
                print("@aws-cdk/aws-glue-alpha.JobActionOptions#timeout", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_Predicate: function _aws_cdk_aws_glue_alpha_Predicate(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("conditions" in p)
                print("@aws-cdk/aws-glue-alpha.Predicate#conditions", "");
            if (p.conditions != null)
                for (const o of p.conditions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Condition(o);
            if ("logical" in p)
                print("@aws-cdk/aws-glue-alpha.Predicate#logical", "");
            if (!visitedObjects.has(p.logical))
                module.exports._aws_cdk_aws_glue_alpha_PredicateLogical(p.logical);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ConditionOptions: function _aws_cdk_aws_glue_alpha_ConditionOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("logicalOperator" in p)
                print("@aws-cdk/aws-glue-alpha.ConditionOptions#logicalOperator", "");
            if (!visitedObjects.has(p.logicalOperator))
                module.exports._aws_cdk_aws_glue_alpha_ConditionLogicalOperator(p.logicalOperator);
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_EventBatchingCondition: function _aws_cdk_aws_glue_alpha_EventBatchingCondition(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("batchSize" in p)
                print("@aws-cdk/aws-glue-alpha.EventBatchingCondition#batchSize", "");
            if ("batchWindow" in p)
                print("@aws-cdk/aws-glue-alpha.EventBatchingCondition#batchWindow", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_TriggerOptions: function _aws_cdk_aws_glue_alpha_TriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("actions" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#actions", "");
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#description", "");
            if ("name" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#name", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_OnDemandTriggerOptions: function _aws_cdk_aws_glue_alpha_OnDemandTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("actions" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#actions", "");
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#description", "");
            if ("name" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#name", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_StartableTriggerOptions: function _aws_cdk_aws_glue_alpha_StartableTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("startOnCreation" in p)
                print("@aws-cdk/aws-glue-alpha.StartableTriggerOptions#startOnCreation", "");
            if ("actions" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#actions", "");
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#description", "");
            if ("name" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#name", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ScheduledTriggerOptions: function _aws_cdk_aws_glue_alpha_ScheduledTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("schedule" in p)
                print("@aws-cdk/aws-glue-alpha.ScheduledTriggerOptions#schedule", "");
            if (!visitedObjects.has(p.schedule))
                module.exports._aws_cdk_aws_glue_alpha_TriggerSchedule(p.schedule);
            if ("startOnCreation" in p)
                print("@aws-cdk/aws-glue-alpha.StartableTriggerOptions#startOnCreation", "");
            if ("actions" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#actions", "");
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#description", "");
            if ("name" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#name", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_EventTriggerOptions: function _aws_cdk_aws_glue_alpha_EventTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("eventBatchingCondition" in p)
                print("@aws-cdk/aws-glue-alpha.EventTriggerOptions#eventBatchingCondition", "");
            if (!visitedObjects.has(p.eventBatchingCondition))
                module.exports._aws_cdk_aws_glue_alpha_EventBatchingCondition(p.eventBatchingCondition);
            if ("actions" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#actions", "");
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#description", "");
            if ("name" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#name", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    }, _aws_cdk_aws_glue_alpha_ConditionalTriggerOptions: function _aws_cdk_aws_glue_alpha_ConditionalTriggerOptions(p) {
        if (p == null)
            return;
        visitedObjects.add(p);
        try {
            if ("predicate" in p)
                print("@aws-cdk/aws-glue-alpha.ConditionalTriggerOptions#predicate", "");
            if (!visitedObjects.has(p.predicate))
                module.exports._aws_cdk_aws_glue_alpha_Predicate(p.predicate);
            if ("startOnCreation" in p)
                print("@aws-cdk/aws-glue-alpha.StartableTriggerOptions#startOnCreation", "");
            if ("actions" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#actions", "");
            if (p.actions != null)
                for (const o of p.actions)
                    if (!visitedObjects.has(o))
                        module.exports._aws_cdk_aws_glue_alpha_Action(o);
            if ("description" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#description", "");
            if ("name" in p)
                print("@aws-cdk/aws-glue-alpha.TriggerOptions#name", "");
        }
        finally {
            visitedObjects.delete(p);
        }
    } };
function print(name, deprecationMessage) {
    const deprecated = process.env.JSII_DEPRECATED;
    const deprecationMode = ["warn", "fail", "quiet"].includes(deprecated) ? deprecated : "warn";
    const message = `${name} is deprecated.\n  ${deprecationMessage.trim()}\n  This API will be removed in the next major release.`;
    switch (deprecationMode) {
        case "fail":
            throw new DeprecationError(message);
        case "warn":
            console.warn("[WARNING]", message);
            break;
    }
}
function getPropertyDescriptor(obj, prop) {
    const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
    if (descriptor) {
        return descriptor;
    }
    const proto = Object.getPrototypeOf(obj);
    const prototypeDescriptor = proto && getPropertyDescriptor(proto, prop);
    if (prototypeDescriptor) {
        return prototypeDescriptor;
    }
    return {};
}
const visitedObjects = new Set();
class DeprecationError extends Error {
    constructor(...args) {
        super(...args);
        Object.defineProperty(this, "name", {
            configurable: false,
            enumerable: true,
            value: "DeprecationError",
            writable: false,
        });
    }
}
function nop() {
}
module.exports = new Proxy({}, {
    get(target, prop, receiver) {
        if (prop === "print")
            return print;
        if (prop === "getPropertyDescriptor")
            return getPropertyDescriptor;
        if (prop === "DeprecationError")
            return DeprecationError;
        return VALIDATORS[prop] ?? nop;
    },
});
